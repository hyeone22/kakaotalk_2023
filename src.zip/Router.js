import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Home from './routes/Home'
import Profiles from './routes/Profiles'
import Auth from './routes/Auth'
import Navigation from './components/Navigation'

function AppRouter({isLoggedIn, userObj}) {
  return (
    <BrowserRouter>
    {isLoggedIn && <Navigation />}
    <Routes>
      {isLoggedIn ? (
        <>
        <Route path='/' element={<Home userObj={userObj} />} />
        <Route path='/profiles' element={<Profiles />} />
        </>
        ) : (
        <Route path='/' element={<Auth />}/>
      )}
    </Routes>
    </BrowserRouter>
  )
}

export default AppRouter
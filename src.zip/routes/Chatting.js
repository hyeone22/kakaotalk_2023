import React, { useState } from 'react'
import { FaPlane,FaWifi,FaMoon,FaBluetoothB,FaBatteryFull,FaListUl,FaSearch,FaAngleLeft,FaPlus,FaSmile,FaMicrophone } from "react-icons/fa";
import Header from '../components/Header';
import '../styles/Chatting.scss';
import packs from '../data/packs.json'
import { useLocation, useParams } from 'react-router-dom';



function Chatting(props) {
  console.log("props->",props);

 
 const locations = useLocation();
 console.log(locations);
 const { } = props;


  return (
    <div>
     <Header  
      h1="Friend Name" a=<i><FaAngleLeft/></i> i=<i><FaListUl/></i>
      style={{background: 'transparent'}} /> 
    <main className='chatting_main'>
      <span className='date_info'>Thursday,March 23, 2023</span>
      <div className='chat_box my'>
    <span className='chat'>Hello!</span>
    <span className='chat'>Hello! This is a test message. Hello!</span>
    <span className='chat'>This is a test message.</span>
    <span className='chat_time'><span>12</span>:<span>08</span></span>
  </div>
    <div className='chat_box other'>
    <div className='other_info'>
      <a href='#'><span className='profile_img empty'></span></a>
      <span className='profile_name'></span>
    </div>
      <span className='chat'></span>
      <span className='chat_time'><span>12</span>:<span>08</span></span>
  </div>    
    </main>
    <footer>
    <span className='plus_btn'><a href="#"><i><FaPlus/></i></a></span>
    <form action="/" method="post">
    <fieldset className='text_box'>
      <legend className='blind'>채팅 입력창</legend>
      <label for="chatting" className='blind'>채팅 입력</label>
      <input type='text' id='chatting' className='text_field'></input>
      <span className='emoticon_btn'><a href="#"><i><FaSmile/></i></a></span>
      <span className='voice_btn'><a href="#"><i><FaMicrophone/></i></a></span>
    </fieldset>
    </form>  
    </footer>  
    </div>
  )
}


export default Chatting
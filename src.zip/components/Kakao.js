import { db } from 'fbase';
import { deleteDoc, doc } from 'firebase/firestore';
import React, { useState } from 'react'

function Kakao(props) {
  const{kakaoObj:{text,id},isOwner} = props;
  const[editing, setEditing] = useState(false);

  const onDeleteClick = async () => {
    const ok = window.confirm("삭제하시겠습니까?");
    if(ok){
      const data = await deleteDoc(doc(db, "kakaos", `/${id}`));
    }
  }

  const toggleEditing = () => setEditing((prev) => !prev);

  return (
    <div>
     {editing ? (
      <>
        <button onClick={toggleEditing}>Cancel</button>
      </>
     ) : (
      <>
        <h4>{text}</h4>
          {isOwner && (
          <>
          <button onClick={onDeleteClick}>Delete Message</button>
          <button onClick={toggleEditing}>Edit Message</button> 
          </>
         )}      
      </>
     )}
  </div>
  )
}
export default Kakao
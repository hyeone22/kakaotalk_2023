import React from 'react'
import { FaRegComment, FaPencilAlt  } from "react-icons/fa";
import { Link } from 'react-router-dom';
import "styles/Myprofile.scss";


function MyHome() {
  return (
    <div>
      <main>
      <section className='background'>
        <h2 className='blind'>My profile background image</h2>
      </section>
        <section className='profile'>
          <h2 className='blind'>My profile info</h2>
          <div className='profile_img empty'></div>
          <div className='profile_cont'>
            <span className='profile_name'></span>
            <input type='mail' className='profile_email' placeholder='Username@gmail.com'/>
            <ul className='profile_menu'>
            <li><a href='#'><span className='icon'><i><FaRegComment/></i></span>My Chatroom</a></li>
            <li><Link to={'/Profiles'}><span className='icon'><i><FaPencilAlt/></i></span>Edit Profile</Link></li>
            </ul>
          </div>
        </section>
    </main>  
    </div>
  )
}

export default MyHome
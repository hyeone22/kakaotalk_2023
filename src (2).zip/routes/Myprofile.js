import Header from 'components/Header';
import MyHome from 'components/Myhome'
import React from 'react'
import { FaUserAlt,FaTimes } from "react-icons/fa";

function Myprofile() {
  return (
    <>
    <Header a=<i><FaTimes/></i> i=<FaUserAlt/> />    
    <MyHome />
    </>

  )
}

export default Myprofile
import React, { useEffect, useState } from 'react'
import { FaPlane,FaWifi,FaMoon,FaBluetoothB,FaBatteryFull,FaListUl,FaSearch,FaAngleLeft,FaPlus,FaSmile,FaMicrophone } from "react-icons/fa";
import Header from '../components/Header';
import '../styles/Chatting.scss';
import { addDoc, collection, onSnapshot, orderBy, query } from 'firebase/firestore';
import { db, storage } from 'fbase';
import Kakao from 'components/Kakao';
import { ref, uploadString, getDownloadURL  } from "firebase/storage";
import { v4 as uuidv4 } from 'uuid';




function Chatting({userObj}) {
  const [kakao, setKakao] = useState('');
  const [kakaos, setKakaos] = useState([]);
  const [attachment, setAttachment] = useState("");

  useEffect(() => {
   
    const q = query(collection(db, "kakaos"),
                    orderBy("createdAt","desc"));
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const newArray = [];
      querySnapshot.forEach((doc) => {
        newArray.push({...doc.data(), id:doc.id});
      });
      setKakaos(newArray);
    });
  },[]);

  const onChange = (e) => {
    e.preventDefault();
    const {target:{value}} = (e);
    setKakao(value);
  }
  const onSubmit = async (e) => {
    e.preventDefault();
    try {
      let attachmentUrl = "";
      if(attachment !== ""){
        const storageRef = ref(storage, `${userObj.uid}/${uuidv4()}`); // 사진을 스토리지에 저장
        const response = await uploadString(storageRef, attachment, 'data_url');
        console.log('response->',response)
        attachmentUrl = await getDownloadURL(ref(storage, response.ref))  
      }  


      const docRef = await addDoc(collection(db, "kakaos"), {
        text: kakao,
        createdAt: Date.now(),
        createrId: userObj.uid,  // 문서를 누가 작성했는지 알아내야함 userObj > 로그인한 사용자 정보
        attachmentUrl
      });
      console.log("Document written with ID: ", docRef.id);
      } catch (e) {
        console.error("Error adding document: ", e);
      }
      setKakao("");
      setAttachment("");  
    }

    const onFileChange = (e) => {
    const {target: {files}} = e;
    
    const theFile = files[0];

    const reader = new FileReader();

    reader.onloadend = (finishedEvent) => {
      const {currentTarget:{result}} = finishedEvent;
      setAttachment(result);
    }
    reader.readAsDataURL(theFile);
    }

    const onclearAttachment = () =>{
      setAttachment("");
    }

  return (
    <div>
     <Header  
      h1="Friend Name" a=<i><FaAngleLeft/></i> i=<i><FaListUl/></i>
      style={{backgroundColor:'white'}}
       /> 
    <main className='chatting_main'>
      <span className='date_info'>Thursday,March 23, 2023</span>
     
      <div className='chat_box my'>
      {kakaos.map(kakao => (
          <Kakao key={kakao.id} kakaoObj={kakao} isOwner={kakao.createrId === userObj.uid}/> 
        ))}
  </div>
    <div className='chat_box other'>
    <div className='other_info'>
      <a href='#'><span className='profile_img empty'></span></a>
      <span className='profile_name'></span>
    </div>
      <span className='chat'></span>
      <span className='chat_time'><span>12</span>:<span>08</span></span>
  </div>    
    </main>
    <footer>
    <form action="/" method="post" onSubmit={onSubmit}>
    <fieldset className='text_box'>
      <legend className='blind'>채팅 입력창</legend>
      <label for="chatting" className='blind'>채팅 입력</label>
      <input type='file' accept='image/*' onChange={onFileChange} />
      <input type='text' id='chatting' className='text_field' value={kakao} onChange={onChange}></input>
      <span className='emoticon_btn'><a href="#"><i><FaSmile/></i></a></span>
      <input type='submit' value='전송' onChange={onChange} />
      {attachment && (
        <div>
        <img src={attachment} width="50" height="50" alt="" />
        <button onClick={onclearAttachment}>Remove</button>  
        </div>
      )}
    </fieldset>
    </form>
    </footer>  
    </div>
  )
}


export default Chatting
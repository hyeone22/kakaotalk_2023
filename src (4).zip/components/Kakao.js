import { db, storage } from 'fbase';
import { deleteDoc, doc, updateDoc } from 'firebase/firestore';
import { deleteObject, ref } from 'firebase/storage';
import React, { useState } from 'react'

function Kakao(props) {
  const{kakaoObj:{text,id,attachmentUrl},isOwner} = props;
  const[editing, setEditing] = useState(false);
  const [newTweet, setNewTweet] = useState(text);

  const onDeleteClick = async () => {
    const ok = window.confirm("삭제하시겠습니까?");
    if(ok){
      const data = await deleteDoc(doc(db, "kakaos", `/${id}`));
      if(attachmentUrl !== ""){
        const desertRef = ref(storage, attachmentUrl);
        await deleteObject(desertRef);
      }
    }
  }

  const toggleEditing = () => setEditing((prev) => !prev);

  const onChange = (e) => {
    const {target:{value}} = e;
    setNewTweet(value);
  }

  const onSubmit = async (e) => {
    e.preventDefault();
    const newTweetRef = doc(db, "kakaos", `/${id}`);

    await updateDoc(newTweetRef, {
      text: newTweet,
      createdAt: Date.now(),
    });
    setEditing(false);
  }

  return (
    <div>
     {editing ? (
      <>
        <form onSubmit={onSubmit}>
          <input type='text' onChange={onChange} value={newTweet} required />
          <input type='submit' value='Update Message' />
        </form>
        <button onClick={toggleEditing}>Cancel</button>
      </>
     ) : (
      <>
        <span className='chat'>{text}</span>
        <img src={attachmentUrl} width='50' height='50' alt="" />
        <span className='chat_time'><span>12</span>:<span>08</span></span>
          {isOwner && (
          <>
          <button onClick={onDeleteClick}>Delete Message</button>
          <button onClick={toggleEditing}>Edit Message</button> 
          </>
         )}      
      </>
     )}
  </div>
  )
}
export default Kakao
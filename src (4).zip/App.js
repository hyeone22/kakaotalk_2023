import React, { useEffect, useState } from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import Index from './routes/Index';
import Chats from './routes/Chats';
import Find from './routes/Find';
import More from './routes/More';
import Profile from './routes/Profile';
import Chatting from './routes/Chatting';
import AppRouter from './Router';
import { authService } from './fbase';
import { onAuthStateChanged } from 'firebase/auth';



function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(authService.currentUser);

  const [userObj, setUserObj] = useState(null);

  useEffect(() => {
    onAuthStateChanged(authService, (user) =>{
      if (user) {
        setIsLoggedIn(user);
        setUserObj(user);
      } else {
        setIsLoggedIn(false);
      }
    });
  },[]);

  return (
    <>
    <AppRouter isLoggedIn={isLoggedIn} userObj={userObj} />
    
    </>
  );
}

export default App;

import Header from 'components/Header';
import { authService, db } from 'fbase';
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { FaUserAlt,FaTimes, FaRegComment } from "react-icons/fa";
import { updateProfile } from 'firebase/auth';
import { collection, onSnapshot, orderBy, query, where } from 'firebase/firestore';


function Profiles({userObj}) {
  const [tweets, setTweets] = useState([]);
  const [newDisplayName, setNewDisplayName] = useState(userObj.displayName);
  const navigate = useNavigate();


  const onLogOutClick = () => {
    authService.signOut();
    navigate('/');
  }

  useEffect(() => {
    const q = query(collection(db, "send"),
                    where("createrId", "==", userObj.uid),
                    orderBy("createdAt","desc"));
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const newArray = [];
      querySnapshot.forEach((doc) => {
        newArray.push({...doc.data(), id:doc.id});
      });
      setTweets(newArray);
    });
  },[]);


  const onSubmit = async(e) => {
    e.preventDefault();
    if (userObj.displayName !== newDisplayName) {
      await updateProfile(userObj, {
        displayName: newDisplayName,
        // photoUrl
      });
    }
  }

  const onChange = (e) => {
    const {target:{value}} = e;
    setNewDisplayName(value);
  }

  return (
    <>
      <Header a=<i><FaTimes/></i> i=<FaUserAlt/> /> 
      <main>
      <section className='background'>
        <h2 className='blind'>My profile background image</h2>
      </section>
        <section className='profile'>
          <h2 className='blind'>My profile info</h2>
          <div className='profile_img empty'></div>
          <div className='profile_cont'>
            <form onSubmit={onSubmit}>
            <input type='text' onChange={onChange} value={newDisplayName}
            placeholder='Display Name' />
            <input type='submit' value='상태메시지' onChange={onChange} />
            </form>
            <button onClick={onLogOutClick}>Log Out</button>
            <span className='profile_name'></span>
            <input type='mail' className='profile_email' placeholder='Username@gmail.com'/>
            <ul className='profile_menu'>
            <li><a href='#'><span className='icon'><i><FaRegComment/></i></span>My Chatroom</a></li>
            </ul>
          </div>
        </section>
    </main>  

    </>
  )
}

export default Profiles